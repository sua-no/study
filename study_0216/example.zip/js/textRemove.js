let i = 0;
let j = 0;
const textArray = ["HTML", "CSS", "Javascript"],
    speed = 100,
    target = document.getElementById("type");


//한글자씩 추출해서 html에 출력 charAt
function type(){}
//한글자씩 html에서 제거 slice
function remove(){}
//다음 문자열로 넘어감
function textNum(){}